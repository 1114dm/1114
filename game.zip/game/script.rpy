define doctor = Character("你（康复治疗师）", color="#4a90e2")
define patient = Character("患者", color="#e74c3c")
define family = Character("家属", color="#e74c3c")
define xitong = Character("系统", color="#4a90e2")
image 1tong = "images/1tong.png" 
image 1xiao = "images/1xiao.png" 
image 1jiashu = "images/1jiashu.png"
image 1ma = "images/1ma.png" 
image 2ma = "images/2ma.png" 
image 2xiao = "images/2xiao.png" 
image 3ma = "images/3ma.png" 
image 3xiao = "images/3xiao.png" 
image bj = "images/bj.png" 

init python:
    import webbrowser


screen warning_dialog(text):
    zorder 100
    frame:
        xsize 700
        ysize 300
        xalign 0.5
        yalign 0.5
        background "#220000dd"
        vbox:
            xalign 0.5
            yalign 0.5
            spacing 20
            text text:
                size 26
                color "#ff6666"
                xmaximum 650
            textbutton "确认" action Return():
                background "#ff4444"
                hover_background "#ff6666"
                text_color "#ffffff"
                text_size 24

label start:
    $ score_icf = 0
    $ score_comm = 0
    $ score_care = 0
    $ score_Therape = 0
    $ feedback = ""


    scene bj
    doctor "欢迎来到康复交互式模拟系统，请选择本次实训病例："
    define config.main_menu_music = "yinyue/1.mp3"

    menu:
        "1. 脑卒中患者":
            jump case_stroke
        "2. 全膝关节置换术（TKA）患者":
            jump case_tka
        "3. 脊髓损伤患者":
            jump case_spinal

label case_stroke:
    scene 1jiashu

    doctor "您好，李先生，我是您的康复治疗师。今天我们来了解一下您的情况。"
    family "医生，我老婆上周刚做完脑出血的手术，那个做手术的医生说可以来康复了，我听我朋友他们说你们这边做的比较好……"
    xitong "脑卒中按性质分哪辆类？"
    menu:
        "1. 缺血性和出血性" :
            $ score_Therape += 5
            call screen warning_dialog("恭喜你，回答正确！")  
        "2. 闭塞性和破裂性":
            call screen warning_dialog("⚠️ 正确答案为1. 缺血性和出血性。")
        "3. 梗塞和出血":
            call screen warning_dialog("⚠️ 正确答案为1. 缺血性和出血性。")
   
    menu:
        "1. 详细询问发病时长、诱发因素、基础慢病、既往脑血管病史及用药情况":
            $ score_comm += 5
            call screen warning_dialog("恭喜你，回答正确！")  
            doctor "老人家，您老婆平时有没有高血压、糖尿病、脑梗病史？"
            family "没有高血压呀现在。不过她前段时间腿疼、牙疼、睡不着觉，隔壁老王比我病还多，我昨天还想扫地来着，手就是不听使唤……（絮絮叨叨、答非所问，持续多说无关内容）"
            doctor "嗯嗯我知道了，您说她现在没有高血压，那她之前有过高血压吗？"
            patient "当然了，现在的老年人谁没有高血压哦，我现在是吃药给吃好了，好像吃的叫什么肖本平什么的……"
            doctor "哦哦，好的我知道了，那您家里人……"
            menu:
                "1. 身体不舒服是一下子出现的，还是慢慢加重的？发病时她是在休息，情绪激动，还是在干活？":
                    call screen warning_dialog("⚠️ 引导式提问，影响评估真实性。")
                "2. 什么时候发病的？是突然得病的吗？当时在干嘛？":
                    $ score_comm += 5
                    call screen warning_dialog("恭喜你，回答正确！")  
                       
        "2.未做任何问诊，直接引导患者抬手、站立行走进行查体":
            $ score_comm += 0
            doctor "那我们先测一下她的肌力吧。"
            scene 1tong
            call screen warning_dialog("⚠️ 未先沟通问诊，直接评估易导致患者紧张、不配合，影响评估真实性。")
            menu:
                "1. 主动诚恳道歉，修正沟通方式：“抱歉，我刚才没有和您好好沟通，您慢慢说，我现在认真记录您的不适。":
                    $ score_comm += 5
                    call screen warning_dialog("恭喜你，回答正确！")  
                "2. 坚持原有强硬沟通，持续施压追问。":
                    scene 1ma
                    call screen warning_dialog("⚠️ 态度太差，警告！")

                
        "3.仅安抚患者焦虑情绪，不开展任何病史与病情问诊":
            doctor "原来是这样，您也别太担心，您老婆看着状态也挺好的……（絮絮叨叨仅安抚情绪）"
            call screen warning_dialog("⚠️ 未开展任何病史与病情问诊，安抚情绪虽然能提高患者的配合度，但也不能推进问诊流程。")

    scene 1xiao
    menu:
        "1. 询问患者主观感受与担忧":
            $ score_care += 5
            call screen warning_dialog("恭喜你，回答正确！")  
            doctor "您现在最担心的是什么？"
            patient "我怕以后我都不能自己走路了，给家里添麻烦……"
            
            menu:
                "1. 您别担心，康复是一个长期的过程，我们慢慢来总会好起来的。" :
                    $ score_care += 5
                    call screen warning_dialog("恭喜你，回答正确！")  
                "2. 那你有什么办法，你不练根本好不起来的。":
                    scene 1ma
                    call screen warning_dialog("⚠️ 语气太差，太过生硬说教。")
                "3. 你爱练不练，你好不好跟我有什么关系。":
                    scene 1ma
                    call screen warning_dialog("⚠️ 未能与患者共情，难以展开治疗。")

        "2. 直接介绍接下来的评估项目":
            doctor "接下来我会给您做几个测试，您配合一下就好。"
            scene 1ma
            call screen warning_dialog("⚠️ 忽视患者情绪，易引发抵触心理，长期可能导致康复依从性下降。")
    
    scene 1xiao
    xitong"偏瘫患者典型的痉挛模式表现为："
    menu:
        "A.上肢屈曲，下肢伸直" :
            $ score_icf += 5
            call screen warning_dialog("恭喜你，回答正确！")  
        "B.上肢伸直，下肢屈曲":
            call screen warning_dialog("⚠️正确答案是A.上肢屈曲，下肢伸直")
        "C.上下肢均伸直":
            call screen warning_dialog("⚠️正确答案是A.上肢屈曲，下肢伸直")
        "D.上下肢均屈曲":
            call screen warning_dialog("⚠️正确答案是A.上肢屈曲，下肢伸直")

    init:
        default selected_ans = {
            "ans1": False,
            "ans2": False,
            "ans3": False,
            "ans4": False,
            "ans5": False,
            "ans6": False,
            "ans7": False}

    label srt:
        call screen quiz_screen
    
        $ score = 0
        if selected_ans["ans2"]:
            $ score += 2
        if selected_ans["ans3"]:
            $ score += 2
        if selected_ans["ans6"] :
            $ score += 2
        if selected_ans["ans7"] :
            $ score += 2
        if selected_ans["ans1"]:
            $ score -= 2
        if selected_ans["ans4"] :
            $ score -= 1
        if selected_ans["ans5"] :
            $ score -= 1

        call screen warning_dialog("答题结束！选择正确加2分，选择错误-1分，你的得分是：[score]/8，正确答案：吞咽障碍，平衡协调障碍，日常生活活动能力障碍，心理障碍")

        $ score_comm += score
        if score_comm==8 :
            $ score_comm +=10

    screen quiz_screen():
        frame:
            xpos 0.5
            ypos 0.5
            anchor (0.5, 0.5)
            xsize 900
            ysize 650
            background "#f5f5f5"
            padding (20, 20)

            vbox:
                spacing 10
                xalign 0.5

                text "患者自述:" xalign 0.5 size 22 color "#333"

                frame:
                    background "#ffffff"
                    xsize 860
                    ysize 150
                    padding (10, 10)
                    text "我现在身体到处都不舒服。一个是我感觉我吞咽有问题，喉咙总感觉堵得慌，不管是喝水还是吃流食，稍不注意就会呛咳。然后吧，我感觉我的平衡感也很差，坐不稳、站不住，手脚也不太听使唤，平时吃饭、穿衣这些小事都做不了，还经常头晕，伤口也隐隐作痛." xalign 0.5 size 18 color "#444"

                text "请选出该患者目前存在的问题（可多选）:" xalign 0.5 size 20 color "#333"

                vbox:
                    spacing 5

                    textbutton "1. 言语障碍":
                        action ToggleDict(selected_ans, "ans1", True, False)
                        xsize 860
                        background "#ffffff"
                        hover_background "#e8f0ff"
                        selected_background "#c9e2ff"

                    textbutton "2. 吞咽障碍":
                        action ToggleDict(selected_ans, "ans2", True, False)
                        xsize 860
                        background "#ffffff"
                        hover_background "#e8f0ff"
                        selected_background "#c9e2ff"

                    textbutton "3. 平衡、协调障碍":
                        action ToggleDict(selected_ans, "ans3", True, False)
                        xsize 860
                        background "#ffffff"
                        hover_background "#e8f0ff"
                        selected_background "#c9e2ff"

                    textbutton "4. 频繁头晕，手术切口存在隐痛":
                        action ToggleDict(selected_ans, "ans4", True, False)
                        xsize 860
                        background "#ffffff"
                        hover_background "#e8f0ff"
                        selected_background "#c9e2ff"

                    textbutton "5. 听力障碍":
                        action ToggleDict(selected_ans, "ans5", True, False)
                        xsize 860
                        background "#ffffff"
                        hover_background "#e8f0ff"
                        selected_background "#c9e2ff"
                
                    textbutton "6. 日常生活活动能力障碍":
                        action ToggleDict(selected_ans, "ans6", True, False)
                        xsize 860
                        background "#ffffff"
                        hover_background "#e8f0ff"
                        selected_background "#c9e2ff"

                    textbutton "7.心理障碍":
                        action ToggleDict(selected_ans, "ans7", True, False)
                        xsize 860
                        background "#ffffff"
                        hover_background "#e8f0ff"
                        selected_background "#c9e2ff"

                    textbutton "提交答案":
                        action Return()
                        xsize 200
                        xalign 0.5
                        background "#4a90e2"
                        hover_background "#357abd"
                        text_color "#ffffff"  

    doctor"接下来我给您做几个功能评估，帮我们制定更精准的方案。"
    scene 1xiao
    xitong"以下哪种是脑卒中常用的运动功能评定方法？"  
    menu:
        "A.FIM":
            call screen warning_dialog("⚠️Brunnstorm分期更为常用")
        "B.MMSE":
            call screen warning_dialog("⚠️MMSE是精神量表")
        "C.Brunnstorm分期":
            $ score_icf += 5
            call screen warning_dialog("恭喜你，回答正确！")  
        "D.ASIA分级":
            call screen warning_dialog("⚠️MMSE是精神量表")
   
    xitong"评估脑卒中患者神经功能缺损的量表有:"
  
    menu:
        "A.MMSE精神量表":
            call screen warning_dialog("不正确，答案是B.Fugl-Meyer量表")
        "B.Fugl-Meyer量表":
            $ score_icf += 5
            call screen warning_dialog("恭喜你，回答正确！")  
        "C.Barthel指数":
            call screen warning_dialog("不正确，答案是B.Fugl-Meyer量表")
        "D.Glasgow昏迷量表":
            call screen warning_dialog("不正确，答案是B.Fugl-Meyer量表")

    
    xitong"评估脑卒中患者吞咽功能常用的方法是:"

    menu:
        "A.纤维喉镜检查":
            call screen warning_dialog("不正确，答案是C.洼田饮水试验")
        "B.吞咽造影检查":
            call screen warning_dialog("不正确，答案是C.洼田饮水试验")
        "C.洼田饮水试验":
            $ score_icf += 5
            call screen warning_dialog("恭喜你，回答正确！")  
        "D.以上都是答案":
            call screen warning_dialog("不正确，答案是C.洼田饮水试验")

    doctor "根据评估结果，我们可以制定以下康复方案，您更倾向哪种？"
    menu:
        "方案1：分阶段康复训练（肌力+平衡+ADL训练）":
            $ score_icf += 10
            $ score_comm += 2
            call screen warning_dialog("恭喜你，回答正确！")  
            doctor "我们会先从肌力训练开始，再加入平衡训练，循序渐进。"
            patient "听起来很稳妥，我愿意试试。"

            
        "方案2：高强度步态训练，快速恢复走路":
            scene 1tong
            call screen warning_dialog("⚠️ 高强度训练风险极高，可能导致：跌倒、脑出血复发、肌肉拉伤、痉挛恶化！")
        
            
           
    scene 1xiao
    doctor "接下来我来给你做一下治疗"
    xitong"偏瘫患者进行床上侧向移动训练时，下列描述正确的是:"
    menu:
        "A.先将健侧足放至患侧足下":
            $ score_Therape +=5
            call screen warning_dialog("恭喜你，回答正确！")  
        "B.用健腿推动患侧腿向床沿移动":
            call screen warning_dialog("不正确，床上转移训练:偏瘫患者:先将健侧足伸到患侧足下;用健侧腿抬起患侧腿向右(左)移动;用健侧足和肩支起臀部，同时将臀部移向右(左)侧;臀部右(左)移动完毕后，再慢慢将肩、头移向右(左)侧。")
          
        "C.用健腿和患腿共同支起臀部":
            call screen warning_dialog("不正确，床上转移训练:偏瘫患者:先将健侧足伸到患侧足下;用健侧腿抬起患侧腿向右(左)移动;用健侧足和肩支起臀部，同时将臀部移向右(左)侧;臀部右(左)移动完毕后，再慢慢将肩、头移向右(左)侧。")
           
        "D.臀部移动完毕后，再移患腿":
            call screen warning_dialog("不正确，床上转移训练:偏瘫患者:先将健侧足伸到患侧足下;用健侧腿抬起患侧腿向右(左)移动;用健侧足和肩支起臀部，同时将臀部移向右(左)侧;臀部右(左)移动完毕后，再慢慢将肩、头移向右(左)侧。")

        "E.将肩、头部侧移后，再移臀部":
            call screen warning_dialog("不正确，床上转移训练:偏瘫患者:先将健侧足伸到患侧足下;用健侧腿抬起患侧腿向右(左)移动;用健侧足和肩支起臀部，同时将臀部移向右(左)侧;臀部右(左)移动完毕后，再慢慢将肩、头移向右(左)侧。")

    xitong"穿/脱上衣的动作成分不包括"

    menu:
        "A.把患侧上肢和手穿进/脱出正确袖管":
            call screen warning_dialog("穿/脱上衣的核心动作成分是围绕将衣。物穿到身上或从身上脱下的一系列步骤，不包括使用后折叠好衣服")
        "B.使用后折叠好衣服":
            $ score_Therape +=5
            call screen warning_dialog("恭喜你，回答正确！")        
        "C.把衣领拉到/脱到健肩":
            call screen warning_dialog("穿/脱上衣的核心动作成分是围绕将衣。物穿到身上或从身上脱下的一系列步骤，不包括使用后折叠好衣服")          
        "D.把衣领拉到/脱到患肩":
            call screen warning_dialog("穿/脱上衣的核心动作成分是围绕将衣。物穿到身上或从身上脱下的一系列步骤，不包括使用后折叠好衣服")
        "E.穿上/脱下健侧上肢袖管":
            call screen warning_dialog("穿/脱上衣的核心动作成分是围绕将衣。物穿到身上或从身上脱下的一系列步骤，不包括使用后折叠好衣服")

    xitong"脑卒中偏瘫患者肢体运动功能训练中，改善挛模式需要注意的是"
    
    menu:
        "A.增强肌力":
            call screen warning_dialog("不正确，应该先改善伸肌与屈肌的平衡，脑卒中后的痉挛模式，核心问题是屈肌和伸肌之间的张力失衡。典型表现是上肢屈肌痉挛、下肢伸肌痉挛，导致患者出现“划圈步态”等异常姿势。")
        "B.加大关节活动范围":
            call screen warning_dialog("不正确，应该先改善伸肌与屈肌的平衡，脑卒中后的痉挛模式，核心问题是屈肌和伸肌之间的张力失衡。典型表现是上肢屈肌痉挛、下肢伸肌痉挛，导致患者出现“划圈步态”等异常姿势。")            
        "C.增强体力":
            call screen warning_dialog("不正确，应该先改善伸肌与屈肌的平衡，脑卒中后的痉挛模式，核心问题是屈肌和伸肌之间的张力失衡。典型表现是上肢屈肌痉挛、下肢伸肌痉挛，导致患者出现“划圈步态”等异常姿势。")          
        "D.改善伸肌与屈肌的平衡":
            $ score_Therape +=5
            call screen warning_dialog("恭喜你，回答正确！")          
        "E.加强平衡训练":
            call screen warning_dialog("不正确，应该先改善伸肌与屈肌的平衡，脑卒中后的痉挛模式，核心问题是屈肌和伸肌之间的张力失衡。典型表现是上肢屈肌痉挛、下肢伸肌痉挛，导致患者出现“划圈步态”等异常姿势。")
    
    xitong"下列通过刷、轻叩皮肤等，促进或抑制运动活动的技术是："

    menu:
        "A.强制性使用技术":
            call screen warning_dialog("不正确，答案是C.Rood技术，它的的核心就是利用特定的感觉刺激，如刷、轻叩、牵拉、挤压皮肤和关节来促进或抑制特定的肌肉反应，从而帮助患者重新获得运动控制。")
        "B.运动再学习技术":
            call screen warning_dialog("不正确，答案是C.Rood技术，它的的核心就是利用特定的感觉刺激，如刷、轻叩、牵拉、挤压皮肤和关节来促进或抑制特定的肌肉反应，从而帮助患者重新获得运动控制。")        
        "C.Rood技术":
            $ score_Therape +=5
            call screen warning_dialog("恭喜你，回答正确！")          
        "D.PNF技术":
            call screen warning_dialog("不正确，答案是C.Rood技术，它的的核心就是利用特定的感觉刺激，如刷、轻叩、牵拉、挤压皮肤和关节来促进或抑制特定的肌肉反应，从而帮助患者重新获得运动控制。")
        "E.Brunnstrom技术":
            call screen warning_dialog("不正确，答案是C.Rood技术，它的的核心就是利用特定的感觉刺激，如刷、轻叩、牵拉、挤压皮肤和关节来促进或抑制特定的肌肉反应，从而帮助患者重新获得运动控制。")
    
    xitong"请选择出正确的脑卒中康复治疗原则:"
        
    menu:
        "A.先近端后远端":
            $ score_Therape +=5
        "B.先远端后近端":
            call screen warning_dialog("不正确，答案是A.先近端后远端")
        "C.先上肢后下肢":
            call screen warning_dialog("不正确，答案是A.先近端后远端")
        "D.先下肢后上肢":
            call screen warning_dialog("不正确，答案是A.先近端后远端")
    jump score_summary

label case_tka:
    scene 2xiao

    doctor "您好，王女士，我是您的康复治疗师。您刚做完全膝关节置换手术，今天我们来聊聊康复计划。"
    patient "医生好，我现在膝盖还是肿的，弯起来也疼，不知道能不能恢复正常走路……"

    menu:
        "1. 询问手术情况与术后感受":
            $ score_care +=10
            doctor "您是什么时候做的手术？现在疼痛大概是几分？"
            patient "术后第3天，现在疼得大概有5分，不敢动。"

        "2. 直接开始关节活动度训练":
            scene 2ma
            $ score_care -= 3
            call screen warning_dialog("⚠️ 术后早期未评估疼痛与肿胀直接训练，可能加重关节肿胀、疼痛，影响伤口愈合。")
            doctor "那我们先开始弯腿训练吧。"

    patient "大夫，我躺着不疼，一弯膝盖伤口就扯着酸胀疼。"
    scene 2xiao
    menu:
        "A.疼就别练了，一直躺着静养":
            call screen warning_dialog("不正确，答案是D") 
        "B.疼痛说明伤口发炎，马上停止所有康复":
            call screen warning_dialog("不正确，答案是D")
        "C.这么点小痛你都忍不了啊，你忍不了来做什么康复？":
            $ score_comm -= 10
            scene 2ma
            call screen warning_dialog("不正确，答案是D")  
        "D. 这是术后正常炎性疼痛，口服镇痛药+冰敷即可缓解，循序渐进练屈膝":
            $ score_comm += 10
            call screen warning_dialog("恭喜你，回答正确！")

    scene 2xiao
    xitong"膝关节置换术一般多久可以开始下地负重:"
    menu:
        "A.1周":
            $ score_icf += 10
            call screen warning_dialog("恭喜你，回答正确！") 
        "B.2周":
            call screen warning_dialog("不正确，答案是A.1周，一般膝关节置换术后，1-3天就可以下地负重")
        "C.3周":
            call screen warning_dialog("不正确，答案是A.1周，一般膝关节置换术后，1-3天就可以下地负重")  
        "D.4周":
            call screen warning_dialog("不正确，答案是A.1周，一般膝关节置换术后，1-3天就可以下地负重")

    patient "大夫，我昨天锻炼的时候伤口流脓、膝盖红肿剧痛，我该怎么办？"
    menu:
        "A.你坚持坚持，我估计锻炼几天，练开粘连症状就会好的":
            call screen warning_dialog("不正确，答案是B") 
        "B.怀疑关节感染，即刻停止康复，马上联系主管医师":
            $ score_comm += 10
            call screen warning_dialog("恭喜你，回答正确！")
        "C.你吃点止痛药后试试吧":
            call screen warning_dialog("不正确，答案是B")  
        "D. 没事的，这么一点点肿，回家静养就可以了":
            call screen warning_dialog("不正确，答案是B")

default score = 0
default order_list = []
default right_order = ["A.是否有疼痛，活动受限", "E.肢体长度和维度测量", "C.关节活动度", "G.肌力", "D.肌张力","F.感觉功能评定","B.协调与平衡评定","H.日常生活活动能力"]

screen click_rehab_order():
    frame:
        xsize 700
        ysize 700
        xalign 0.5
        yalign 0.5
        background"#f5f5f5"
        
        vbox: 
            xalign 0.5
            yalign 0.3
            spacing 12
            text "请按正确评估顺序点击选项" size 24
            text "已选顺序：[order_list]" size 22
            text "当前得分：[score]" size 22

            textbutton "A.是否有疼痛，活动受限" action If("A" not in order_list, 
                [SetVariable("order_list", order_list + ["A"])])
            textbutton "B.协调与平衡评定" action If("B" not in order_list, 
                [SetVariable("order_list", order_list + ["B"])])
            textbutton "C.关节活动度" action If("C" not in order_list, 
                [SetVariable("order_list", order_list + ["C"])])
            textbutton "D.肌张力" action If("D" not in order_list, 
                [SetVariable("order_list", order_list + ["D"])])  
            textbutton "E.肢体长度和维度测量" action If("E" not in order_list, 
                [SetVariable("order_list", order_list + ["E"])])  
            textbutton "F.感觉功能评定" action If("F" not in order_list, 
                [SetVariable("order_list", order_list + ["F"])]) 
            textbutton "G.肌力" action If("G" not in order_list, 
                [SetVariable("order_list", order_list + ["G"])]) 
            textbutton "H.日常生活活动能力" action If("H" not in order_list, 
                [SetVariable("order_list", order_list + ["H"])]) 
            null height 20
            textbutton "提交答案" action Return()

label st:
    "请按正确顺序点击选项。"
    $ order_list = []
    $ score = 0
    call screen click_rehab_order()

    if order_list == right_order:
        $ score += 20
        "排序正确！+10分"
    else:
        "顺序不对哦。"
        "你的顺序：[order_list]" "正确顺序：[right_order]"

    "本题得分：[score]"
  
    $ score_icf += score
    


    doctor "根据评估结果，我们制定了两个康复方向，您看您倾向哪一种？"
    menu:
        "方案1：循序渐进（消肿止痛→被动活动→主动活动）":
            $ score_comm += 10
            doctor "我们先从冰敷消肿、股四头肌等长收缩开始，再慢慢增加关节活动度训练。"
            patient "这样我心里踏实多了，就按这个来。"

        "方案2：快速屈曲训练，争取一周弯到90度":
            call screen warning_dialog("⚠️ 过早高强度屈曲训练，可能导致关节出血、假体周围骨折、疼痛加剧！")
            patient "会不会……太急了？"
            scene 2ma
    
    scene 2xiao
    doctor "通过一系列的评估，我们开始治疗吧！"
    xitong"膝关节置换术后训练应遵循的原则是？"
    menu:
        "A.循序渐进":
            $ score_Therape +=10
            call screen warning_dialog("恭喜你，回答正确！")
        "B.早期干预":
            call screen warning_dialog("不正确，正确答案是循序渐进")
        "C.高强度训练":
            call screen warning_dialog("不正确，正确答案是循序渐进")  
        "D.随意进行":
            call screen warning_dialog("不正确，正确答案是循序渐进")
    
    xitong"膝关节置换术后早期（术后0-2周）康复的首要目标是:"
    menu:
        "A.恢复正常步态":
            call screen warning_dialog("不正确，答案是C.控制炎症与肿胀")
        "B.强化股四头肌肌力":
            call screen warning_dialog("不正确，答案是C.控制炎症与肿胀")
        "C.控制炎症与肿胀":
            $ score_Therape +=10
            call screen warning_dialog("恭喜你，回答正确！")  
        "D.达到全范围关节活动度":
            call screen warning_dialog("不正确，答案是C.控制炎症与肿胀")
    
    xitong"术后进行股四头肌等长收缩训练的作用是:"
    menu:
        "A.增强肌肉力量":
            call screen warning_dialog("不正确，答案是D.以上都是")
        "B.改善关节灵活性":
            call screen warning_dialog("不正确，答案是D.以上都是")
        "C.促进血液循环":
            call screen warning_dialog("不正确，答案是D.以上都是")  
        "D.以上都是":
            $ score_Therape +=10
            call screen warning_dialog("恭喜你，回答正确！") 
    jump score_summary

label case_spinal:
    scene 3xiao
    doctor "您好，张先生，我是您的康复治疗师。您是胸10水平脊髓损伤，今天我们来聊聊您的康复目标。"
    patient "我肚脐下面一点都没知觉，腿动不了，是不是以后永远站不起来了？"
    menu:
        "A.你这个没办法了，这辈子只能一直卧床，没必要来康复":
            call screen warning_dialog("不正确，答案是B") 
        "B.T10损伤保留躯干控制，规范康复可坐轮椅、站立架站立，部分实现轮椅独立生活":
            $ score_comm += 10
            call screen warning_dialog("恭喜你，回答正确！")
        "C.不用太担心，你马上就能下地正常走路，练两天就能痊愈的":
            call screen warning_dialog("不正确，答案是B")  
        "D. 你这个情况，吃药就能修复神经，不用做康复训练的":
            call screen warning_dialog("不正确，答案是B")
    
    patient "医生，我小便憋不住、漏尿，有时候排不干净怎么办？"
    menu:
        "A.那你少喝点水就不会漏了吧":
            call screen warning_dialog("不正确，答案是B") 
        "B.我后面会指导你进行间歇导尿+膀胱训练，到时候可以规律饮水，重建膀胱节律":
            $ score_comm += 10
            call screen warning_dialog("恭喜你，回答正确！")
        "C.那你多喝点水吧，我们大量灌水强行冲尿试试":
            call screen warning_dialog("不正确，答案是B")  
        "D. 这个你们都会有的，不用管理，得这个病就是这样的":
            scene 3ma
            call screen warning_dialog("不正确，答案是B")
    
    scene 3xiao    
    xitong"请选择您接下来要做的事:"
    menu:
        "1. 询问损伤情况与功能障碍":
            $ score_comm += 10
            doctor "您受伤多久了？现在有没有压疮或者大小便方面的问题？"
            patient "受伤1个月了，屁股上有点红，小便一直靠导尿管。"
        "2. 直接开始站立训练":
            $ score_comm -= 3
            call screen warning_dialog("⚠️ 未评估体位性血压、皮肤状况直接训练，可能引发体位性低血压、晕厥、压疮加重！")
            doctor "那我们先试试站床吧。"
            jump bad_decision_branch

    xitong"ASIA评定中T10脊髓损伤关键感觉皮节定位:"
    menu:
        "A. 胸骨角平面":
            call screen warning_dialog("不正确，答案是 T10脊髓损伤对应脐水平") 
        "B. 乳头平面":
            call screen warning_dialog("不正确，答案是 T10脊髓损伤对应脐水平")
        "C. 脐水平":
            $ score_icf += 10
            call screen warning_dialog("恭喜你，回答正确！")  
        "D. 腹股沟":
            call screen warning_dialog("不正确，答案是 T10脊髓损伤对应脐水平")
    
    xitong"ASIA分级，损伤平面以下运动、感觉完全消失为:" 
    menu:
        "A. ASIA A级":
            $ score_icf += 10
            call screen warning_dialog("恭喜你，回答正确！") 
        "B. ASIA B级":
            call screen warning_dialog("不正确，答案是A级")
        "C. ASIA C级":
            call screen warning_dialog("不正确，答案是A级")  
        "D. ASIA D级":
            call screen warning_dialog("不正确，答案是A级")

    doctor "根据评估结果，我们的康复目标分阶段制定，您看您更认同哪一种？"
    menu:
        "方案1：先预防并发症（压疮、尿路感染、关节挛缩），再逐步训练转移与平衡":
            $ score_icf += 10
            doctor "我们先做好皮肤护理和膀胱管理，预防并发症，再从床上活动、转移训练开始。"
            patient "这样稳一点，我也能慢慢接受现状。"

        "方案2：以站立和行走为首要目标，立刻开始高强度训练":
            call screen warning_dialog("⚠️ 过早高强度训练，可能导致体位性低血压、骨折、压疮加重、患者严重心理受挫！")
            patient "可是……我现在站都站不起来啊……"
            scene 3ma

    scene 3xiao   
    doctor "通过一系列的评估，接下来我们开始进行治疗"  
    patient "医生，我受不了了你给我的腿弄得太痛了！！！"
    menu:
        "A.我知道我知道，没事的，我们再练一下就不痛了":
            call screen warning_dialog("不正确，答案是B")
        "B.立即停止，评估疼痛原因，调整训练强度":
            $ score_care +=10
            call screen warning_dialog("恭喜你，回答正确！")
        "C.那我们几天先到这里吧！ ":
            call screen warning_dialog("不正确，答案是B")  
        "D.你一个大男人，怎么那么娇气，能不能练？":
            call screen warning_dialog("不正确，答案是B")
    
    xitong"T10完全性脊髓损伤床上移行训练主要依靠？"
    menu:
        "A.下肢屈伸发力":
            call screen warning_dialog("不正确，答案是B上肢撑床+残存腹壁肌群")
        "B.上肢撑床+残存腹壁肌群":
            $ score_Therape +=10
            call screen warning_dialog("恭喜你，回答正确！")
        "C.腰背伸肌 ":
            call screen warning_dialog("不正确，答案是B上肢撑床+残存腹壁肌群")  
        "D.髋周肌群":
            call screen warning_dialog("不正确，答案是B上肢撑床+残存腹壁肌群")
    
    xitong"T10损伤患者上肢肌力强化目的不包括？"
    menu:
        "A.轮椅驱动":
            call screen warning_dialog("不正确，独立行走是下肢强化的目的")
        "B.床椅转移":
            call screen warning_dialog("恭喜你，回答正确！")
        "C.独立行走 ":
            $ score_Therape +=10
            call screen warning_dialog("不正确，独立行走是下肢强化的目的")  
        "D.身体重心转移":
            call screen warning_dialog("不正确，独立行走是下肢强化的目的")
    
    xitong"完全性T10脊髓损伤急性期卧床，首选体位摆放预防挛缩的是"
    menu:
        "A.长期俯卧位":
            call screen warning_dialog("不正确，答案是D.仰卧+定时健侧、患侧侧卧，踝中立位摆放")
        "B.双下肢悬空外展":
            call screen warning_dialog("不正确，答案是D.仰卧+定时健侧、患侧侧卧，踝中立位摆放")
        "C.屈膝垫高持续固定 ":
            call screen warning_dialog("不正确，答案是D.仰卧+定时健侧、患侧侧卧，踝中立位摆放")  
        "D.仰卧+定时健侧、患侧侧卧，踝中立位摆放":
            $ score_Therape +=10
            call screen warning_dialog("恭喜你，回答正确！")
    jump score_summary


label score_summary:
    $ total_score = score_icf + score_comm + score_care + score_Therape 
    $ icf_str = str(score_icf)
    $ comm_str = str(score_comm)
    $ care_str = str(score_care)
    $ Therape_str = str(score_Therape)
    $ total_str = str(total_score)

    doctor "本次实训结束，您的综合评分如下："
    doctor "ICF功能评估得分：[icf_str]/30"
    doctor "沟通技巧得分：[comm_str]/30"
    doctor "人文关怀得分：[care_str]/10"
    doctor "康复治疗科学性得分：[Therape_str]/30"
    doctor "总分：[total_str]/100"

    if total_score >= 25:
        doctor "恭喜！您的康复决策科学规范，充分体现了ICF理念与人文关怀。"
    elif total_score >= 15:
        doctor "您的决策基本合理，但在评估流程或沟通细节上仍有提升空间。"
    else:
        doctor "您的决策存在较多疏漏，可能给患者带来风险，请回顾实训过程，优化临床思维。"

    menu:
        "重新选择病例":
            jump start
        "退出":
            return
        "其他/意见反馈":
            jump feedback_branch

label feedback_branch:


    $ webbrowser.open("https://f.wps.cn/g/weD1L2oC/")

    doctor "✅ 请您完成评分与意见反馈，感谢您的参与！"

    menu:
        "返回主菜单":
            jump start
        "退出":
            return
